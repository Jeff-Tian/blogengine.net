﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Globalization;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using zizhujy.Utility;

namespace zizhujy.HttpHandlers
{
    public class ImageGuardHandler : IHttpHandler
    {
        //public void ProcessRequest(System.Web.HttpContext context)
        //{
        //    HttpResponse response = context.Response;
        //    HttpRequest request = context.Request;
        //    string imagePath = null;

        //    // Check whether the page requesting the image is from your site.
        //    if (request.UrlReferrer != null)
        //    {
        //        // Perform a case-insensitive comparison of the referer.
        //        if (string.Compare(request.Url.Host, request.UrlReferrer.Host, true, CultureInfo.InvariantCulture) == 0)
        //        {
        //            // The requesting host is correct.
        //            // Allow the image to be served(if it exists).
        //            imagePath = request.PhysicalPath;
        //            if (!File.Exists(imagePath))
        //            {
        //                response.Status = "Image not found";
        //                response.StatusCode = 404;
        //                return;
        //            }
        //        }
        //    }

        //    if (imagePath == null)
        //    {
        //        // No valid image was allowed.
        //        // Return the warning image instead of the requested image.
        //        // Rather than hard-code this image, you could retrieve it from the web.config file (using the <appSettings> section or a custom section).
                
        //        //imagePath = context.Server.MapPath("~/Images/notAllowed.gif");
        //        imagePath = context.Server.MapPath(System.Configuration.ConfigurationManager.AppSettings.Get("NotAllowedImage").ToString());
        //    }

        //    // Set the content type to the appropriate image type.
        //    response.ContentType = "image/" + Path.GetExtension(imagePath).ToLower();

        //    // Serve the image.
        //    response.WriteFile(imagePath);
        //    //Image image = Image.FromFile(imagePath);
        //    //image = ImageHandler.WatermarkHandler.AddCopyrightText(image, "www.zizhujy.com", ImageHandler.CopyrightPosition.BottomRight);
        //    //image.Save(response.OutputStream, GetImageFormatByExtension(Path.GetExtension(imagePath)));

        //    //image.Dispose();
        //}

        public void ProcessRequest(System.Web.HttpContext context)
        {
            HttpResponse response = context.Response;
            HttpRequest request = context.Request;
            string imagePath = null;

            // Check whether the page requesting the image is from your site.
            if (request.UrlReferrer != null)
            {
                // Perform a case-insensitive comparison of the referer.
                if (string.Compare(request.Url.Host, request.UrlReferrer.Host, true, CultureInfo.InvariantCulture) == 0)
                {
                    // The requesting host is correct.
                    // Allow the image to be served(if it exists).
                    imagePath = request.PhysicalPath;
                    if (!File.Exists(imagePath))
                    {
                        response.Status = "Image not found";
                        response.StatusCode = 404;
                        return;
                    }
                    else
                    {
                        // Serve the image normally
                        response.WriteFile(imagePath);
                        return;
                    }
                }
                else
                {
                    // Add watermark to the image
                    imagePath = request.PhysicalPath;

                    // Set the content type to the appropriate image type.
                    response.ContentType = "image/" + Path.GetExtension(imagePath).Replace(".", "").ToLower();

                    // Serve the image.
                    Image image = Image.FromFile(imagePath);

                    ImageHandler.TextWatermarker txtWatermarker = new ImageHandler.TextWatermarker(image, "www.zizhujy.com");
                    txtWatermarker.AddWatermark();

                    image = txtWatermarker.WatermarkedImage;
                    //image.Save(response.OutputStream, ImageHelper.GetImageFormatByExtension(Path.GetExtension(imagePath)));

                    MemoryStream mem = new MemoryStream();
                    image.Save(mem, ImageHelper.GetImageFormatByExtension(Path.GetExtension(imagePath)));

                    // Write the MemoryStream data to the OutputStream
                    mem.WriteTo(response.OutputStream);

                    mem.Dispose();

                    image.Dispose();
                    txtWatermarker.Dispose();
                    return;
                }
            }
            else
            {
                // Add watermark to the image
                imagePath = request.PhysicalPath;

                // Set the content type to the appropriate image type.
                response.ContentType = "image/" + Path.GetExtension(imagePath).Replace(".","").ToLower();

                // Serve the image.
                Image image = Image.FromFile(imagePath);
                ImageHandler.TextWatermarker txtWatermarker = new ImageHandler.TextWatermarker(image, "www.zizhujy.com");
                txtWatermarker.AddWatermark();
                image = txtWatermarker.WatermarkedImage;

                // If the image is in PNG format, then it can be saved into response.OutputStream directly 
                ImageFormat format = ImageHelper.GetImageFormatByExtension(Path.GetExtension(imagePath));
                //if (format.Equals(ImageFormat.Png))
                if (true)
                {
                    // Create the PNG in memory
                    MemoryStream mem = new MemoryStream();
                    image.Save(mem, ImageFormat.Png);

                    // Write the MemoryStream data to the output stream.
                    mem.WriteTo(response.OutputStream);
                    mem.Dispose();
                }
                else
                {
                    image.Save(response.OutputStream, format);
                }

                image.Dispose();
                txtWatermarker.Dispose();
                return;
            }
        }

        public bool IsReusable
        {
            get { return true; }
        }
    }
}