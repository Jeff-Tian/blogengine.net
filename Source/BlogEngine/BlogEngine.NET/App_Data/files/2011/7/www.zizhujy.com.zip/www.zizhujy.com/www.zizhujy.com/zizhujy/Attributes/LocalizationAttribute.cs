﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading;
using System.Globalization;

namespace zizhujy.Attributes
{
    public class LocalizationAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (filterContext.RouteData.Values["culture"] != null &&
                !string.IsNullOrWhiteSpace(filterContext.RouteData.Values["culture"].ToString()))
            {
                // 从路由数据 (url) 里设置语言
                var lang = filterContext.RouteData.Values["culture"].ToString();
                Thread.CurrentThread.CurrentUICulture = CultureInfo.CreateSpecificCulture(lang);
            }
            else
            {
                // 从 cookie 里读取语言设置
                var cookie = filterContext.HttpContext.Request.Cookies["_culture"];
                var langHeader = string.Empty;
                if (cookie != null)
                {
                    // 根据 cookie 设置语言
                    langHeader = cookie.Value;
                    Thread.CurrentThread.CurrentUICulture = CultureInfo.CreateSpecificCulture(langHeader);
                }
                else
                {
                    // 如果读取 cookie 失败则设置默认语言
                    langHeader = filterContext.HttpContext.Request.UserLanguages[0];
                    Thread.CurrentThread.CurrentUICulture = CultureInfo.CreateSpecificCulture(langHeader);
                }
                // 把语言值设置到路由值里
                filterContext.RouteData.Values["culture"] = langHeader;
            }

            // 把设置保存进 cookie
            HttpCookie cookieToCreate = new HttpCookie("_culture", Thread.CurrentThread.CurrentUICulture.Name);
            cookieToCreate.Expires = DateTime.Now.AddYears(1);
            filterContext.HttpContext.Response.SetCookie(cookieToCreate);

            base.OnActionExecuting(filterContext);
        }
    }
}
