﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace zizhujy.Controllers
{
    public class ApplicationFactoryController : Controller
    {
        //
        // GET: /ApplicationFactory/

        public ActionResult Index()
        {
            return View();
        }

    }
}
