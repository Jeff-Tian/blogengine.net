﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using zizhujy.ImageHandler;

namespace zizhujy.Controllers
{
    public class TestController : Controller
    {
        //
        // GET: /Test/

        public void Index()
        {
            // Create the in-memory bitmap where you will draw the image.
            // This bitmap is 300 pixels wide and 50 pixels high.
            Bitmap image = new Bitmap(300, 50);

            Graphics g = Graphics.FromImage(image);

            // Draw a solid white rectangle.
            // Start from point (1,1).
            // Make it 298 ixels wide and 48 pixels high.
            g.FillRectangle(Brushes.White, 1, 1, 298, 48);
            Font font = new Font("Arial", 20, FontStyle.Regular);
            
            g.DrawString("http://www.zizhujy.com", font, Brushes.Blue, 10, 5);

            Response.ContentType = "image/gif";
            // Render the image to the output stream.
            image.Save(Response.OutputStream, System.Drawing.Imaging.ImageFormat.Gif);

            g.Dispose();
            image.Dispose();
        }

        public void AddWatermark2()
        {
            Image originImage = Image.FromFile(@"C:\1305211066-1784_600-0_6-0.jpg");
            //Image image = ImageHandler.WatermarkHandler.AddCopyrightText(originImage, "copyright", Color.FromArgb(153,0,0,0),Color.FromArgb(153,255,255,255),
            //    1,1,"Arial", FontStyle.Bold, StringAlignment.Far, 72f,72f);

            //Image image = ImageHandler.WatermarkHandler.AddCopyrightText(originImage, "中文", CopyrightPosition.TopLeft);
            //image = ImageHandler.WatermarkHandler.AddCopyrightText(image, "copyright", CopyrightPosition.TopCenter);
            //image = ImageHandler.WatermarkHandler.AddCopyrightText(image, "copyright", CopyrightPosition.TopRight);
            //image = ImageHandler.WatermarkHandler.AddCopyrightText(image, "copyright", CopyrightPosition.MiddleLeft);
            //image = ImageHandler.WatermarkHandler.AddCopyrightText(image, "copyright", CopyrightPosition.MiddleCenter);
            //image = ImageHandler.WatermarkHandler.AddCopyrightText(image, "copyright", CopyrightPosition.MiddleRight);
            //image = ImageHandler.WatermarkHandler.AddCopyrightText(image, "copyright", CopyrightPosition.BottomLeft);
            //image = ImageHandler.WatermarkHandler.AddCopyrightText(image, "copyright", CopyrightPosition.BottomCenter);
            //image = ImageHandler.WatermarkHandler.AddCopyrightText(image, "copyright", CopyrightPosition.BottomRight);

            TextWatermarker txtWatermarkder = new TextWatermarker(originImage, "Hello");
            txtWatermarkder.HorizontalPosition = WatermarkHorizontalPostion.Right;
            txtWatermarkder.VerticalPosition = WatermarkVerticalPostion.Bottom;
            Image image = txtWatermarkder.AddWatermark();

            Response.ContentType = "image/jpeg";
            image.Save(Response.OutputStream, System.Drawing.Imaging.ImageFormat.Jpeg);

            originImage.Dispose();
            image.Dispose();
            txtWatermarkder.Dispose();
        }

        public void AddWatermark()
        {
            // First, add the image watermark
            Image originImage = Image.FromFile(@"C:\source.jpg");
            Image watermark = Image.FromFile(@"C:\clock.png");

            ImageWatermarker imgWatermarker = new ImageWatermarker(originImage, watermark);
            // You can set the watermark size, if you not then the watermark will be its original size by default
            imgWatermarker.SetWatermarkHeight(80);
            imgWatermarker.AddWatermark();

            // Second, add the text watermark
            TextWatermarker txtWatermarker = new TextWatermarker(imgWatermarker.WatermarkedImage, "www.zizhujy.com");
            txtWatermarker.Position = WatermarkPostion.TopLeft;
            txtWatermarker.AddWatermark();

            // Response and show the watermarked image in the browser
            Response.ContentType = "image/jpeg";
            // Note: save the secondly watermarked image 
            //  (txtWatermarker not imgWatermarker because the txtWatermarker comes after than imgWatermarker)
            txtWatermarker.WatermarkedImage.Save(Response.OutputStream, System.Drawing.Imaging.ImageFormat.Jpeg);

            imgWatermarker.Dispose();
            watermark.Dispose();
            originImage.Dispose();
        }


            //Image originImage = Image.FromFile(@"C:\source.jpg");
            //Image watermark = Image.FromFile(@"C:\clock.png");
            //ImageWatermarker imgWatermarker = new ImageWatermarker(originImage, watermark);
            //imgWatermarker.Position = WatermarkPostion.BottomRight;
            //imgWatermarker.SetWatermarkHeight(70);

            //imgWatermarker.ForegroundOpacity = 0.5;
            //imgWatermarker.AddWatermark();

            //TextWatermarker txtWatermark = new TextWatermarker(imgWatermarker.WatermarkedImage, "www.zizhujy.com");
            //txtWatermark.Position = WatermarkPostion.TopLeft;
            //txtWatermark.AddWatermark();
            
            //Response.ContentType = "image/jpeg";
            //txtWatermark.WatermarkedImage.Save(Response.OutputStream, System.Drawing.Imaging.ImageFormat.Jpeg);

            //originImage.Dispose();
            //watermark.Dispose();
            //imgWatermarker.Dispose();

            //txtWatermark.Dispose();
        //}

        public void AddWatermark3()
        {
            Image originImage = Image.FromFile(@"C:\1305211066-1784_600-0_6-0.jpg");
            Image watermark = Image.FromFile(@"C:\logo.png");
            ImageWatermarker imgWatermarker = new ImageWatermarker(originImage, watermark);
            imgWatermarker.Position = WatermarkPostion.TopRight;
            imgWatermarker.ForegroundOpacity = 0.9;
            imgWatermarker.AddWatermark();
            
            Response.ContentType = "image/jpeg";
            imgWatermarker.WatermarkedImage.Save(Response.OutputStream, System.Drawing.Imaging.ImageFormat.Jpeg);

            originImage.Dispose();
            watermark.Dispose();
            imgWatermarker.Dispose();
        }

        public void AddWatermark4()
        {
            //Image originImage = Image.FromFile(@"C:\1305211066-1784_600-0_6-0.jpg");
            
            //Image image = ImageHandler.WatermarkHandler.AddCopyrightText(originImage, "Hello", Color.FromArgb(153, 0, 0,0), Color.FromArgb(153, 255,255,255), new int[] {20}, CopyrightPosition.BottomRight, 0.01, 1, 1, "Arial", FontStyle.Regular, 72f, 72f);

            //Response.ContentType = "image/jpeg";
            //image.Save(Response.OutputStream, System.Drawing.Imaging.ImageFormat.Jpeg);

            //originImage.Dispose();
            //image.Dispose();
        }
    }
}
