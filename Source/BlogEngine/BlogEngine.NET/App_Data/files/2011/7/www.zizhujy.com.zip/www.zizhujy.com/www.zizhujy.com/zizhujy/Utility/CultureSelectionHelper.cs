﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Routing;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.Threading;

namespace zizhujy.Utility
{
    public static class CultureSelectionHelper
    {
        public class Culture
        {
            public string Url { get; set; }
            public string ActionName { get; set; }
            public string ControllerName { get; set; }
            public RouteValueDictionary RouteValues { get; set; }
            public bool IsSelected { get; set; }

            public MvcHtmlString HtmlSafeUrl
            {
                get
                {
                    return MvcHtmlString.Create(Url);
                }
            }

        }

        public static Culture CultureUrl(this HtmlHelper helper, string cultureName, string cultureRouteName = "culture", bool strictSelected = false)
        {
            // set the input culture to lower
            cultureName = cultureName.ToLower();
            // retrieve the route values from the view context
            var routeValues = new RouteValueDictionary(helper.ViewContext.RouteData.Values);
            // copy the query strings into the route values to generate the link
            var queryString = helper.ViewContext.HttpContext.Request.QueryString;
            foreach (string key in queryString)
            {
                if (queryString[key] != null && !string.IsNullOrWhiteSpace(key))
                {
                    if (routeValues.ContainsKey(key))
                    {
                        routeValues[key] = queryString[key];
                    }
                    else
                    {
                        routeValues.Add(key, queryString[key]);
                    }
                }
            }
            var actionName = routeValues["action"].ToString();
            var controllerName = routeValues["controller"].ToString();
            // set the culture into route values
            routeValues[cultureRouteName] = cultureName;
            // generate the culture specify url
            var urlHelper = new UrlHelper(helper.ViewContext.RequestContext, helper.RouteCollection);
            var url = urlHelper.RouteUrl("Localization", routeValues);
            // check whether the current thread ui culture is this culture
            var currentCultureName = Thread.CurrentThread.CurrentUICulture.Name.ToLower();
            var isSelected = strictSelected ? currentCultureName == cultureName : currentCultureName.StartsWith(cultureName);

            return new Culture() { Url = url, ActionName = actionName, ControllerName = controllerName, RouteValues = routeValues, IsSelected = isSelected };

        }

        public static MvcHtmlString CultureSelectionLink(this HtmlHelper helper, string cultureName, string selectedText, string unselectedText, IDictionary<string, object> htmlAttributes, string cultureRouteName = "culture", bool strictSelected = false)
        {
            var culture = helper.CultureUrl(cultureName, cultureRouteName, strictSelected);
            var link = helper.RouteLink(culture.IsSelected ? selectedText : unselectedText, "Localization", culture.RouteValues, htmlAttributes);
            return link;
        }
    }
}