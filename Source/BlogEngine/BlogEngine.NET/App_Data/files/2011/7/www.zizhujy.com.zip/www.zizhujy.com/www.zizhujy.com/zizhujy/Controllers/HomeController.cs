﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using zizhujy.Attributes;

namespace zizhujy.Controllers
{
    [Localization]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = Resources.Application.Name;

            return View();
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
