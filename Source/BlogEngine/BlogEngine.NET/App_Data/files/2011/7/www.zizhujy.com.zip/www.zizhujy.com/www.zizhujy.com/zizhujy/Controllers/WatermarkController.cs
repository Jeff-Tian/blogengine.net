﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using zizhujy.Models;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using zizhujy.Utility;

namespace zizhujy.Controllers
{
    public class WatermarkController : Controller
    {
        //
        // GET: /Watermark/

        public ActionResult Index()
        {
            return View();
        }

        //
        // POST: /Watermark/

        [HttpPost]
        public void Index(TextWatermarkModel model)
        {
            if (ModelState.IsValid)
            {

                Response.ContentType = "image/jpeg";
                ImageHandler.TextWatermarker txtWatermarker = new ImageHandler.TextWatermarker(model.Image, model.CopyrightText);
                txtWatermarker.ChangeFontFamily(model.FontFamily, model.Bold, model.Italic, model.Underline, model.StrikeThrough);
                txtWatermarker.Position = model.CopyrightPosition;
                txtWatermarker.AddWatermark();
                txtWatermarker.WatermarkedImage.Save(Response.OutputStream, System.Drawing.Imaging.ImageFormat.Jpeg);
                txtWatermarker.Dispose();
            }
            else
            {
            }
        }
    }
}
