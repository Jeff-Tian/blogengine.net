﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Drawing.Imaging;

namespace zizhujy.Utility
{
    public static class ImageHelper
    {
        public static ImageFormat GetImageFormatByExtension(string extension)
        {
            ImageFormat format = null;
            switch (extension.Replace(".","").ToLower())
            {
                case "png":
                    format = ImageFormat.Png;
                    break;

                case "jpg":
                    format = ImageFormat.Jpeg;
                    break;

                case "gif":
                    format = ImageFormat.Gif;
                    break;

                case "ico":
                    format = ImageFormat.Icon;
                    break;

                case "bmp":
                    format = ImageFormat.Bmp;
                    break;

                default:
                    break;
            }

            return format;
        }
    }
}