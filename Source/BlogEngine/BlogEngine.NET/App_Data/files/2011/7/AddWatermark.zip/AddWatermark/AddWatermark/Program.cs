﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace AddWatermark
{
    class Program
    {
        static void Main(string[] args)
        {
            string workingDirectory = @"C:\";
            string copyright = "www.zizhujy.com";

            Image photo = Image.FromFile(workingDirectory + "\\1305211066-1784_600-0_6-0.jpg");
            int width = photo.Width;
            int height = photo.Height;

            Bitmap bitmap = new Bitmap(width, height, PixelFormat.Format24bppRgb);
            Graphics g = Graphics.FromImage(bitmap);

            Image imgWatermark = new Bitmap(workingDirectory + "\\logo.png");
            int widthWatermark = imgWatermark.Width;
            int heightWatermark = imgWatermark.Height;

            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.DrawImage(photo, new Rectangle(0, 0, width, height), 0, 0, width, height, GraphicsUnit.Pixel);

            int[] sizes = new int[] { 16, 14, 12, 10, 8, 6, 4 };
            Font font = null;
            SizeF size = new SizeF();
            for (int i = 0; i < 7; i++)
            {
                font = new Font("arial", sizes[i], FontStyle.Bold);
                size = g.MeasureString(copyright,font);

                if ((ushort)size.Width < (ushort)width)
                    break;
            }

            int yPixlesFromBottom = (int)(height * .05);
            float yPosFromBottom = ((height - yPixlesFromBottom) - (size.Height / 2));
            float xCenterOfImg = (width / 2);

            StringFormat strFormat = new StringFormat();
            strFormat.Alignment = StringAlignment.Center;

            SolidBrush semiTransBrushShadow =   new SolidBrush(Color.FromArgb(153, 0, 0, 0));

            g.DrawString(copyright, font, semiTransBrushShadow, new PointF(xCenterOfImg + 1, yPosFromBottom + 1), strFormat);

            SolidBrush semiTransBrush = new SolidBrush(Color.FromArgb(153, 255, 255, 255));

            g.DrawString(copyright, font, semiTransBrush, new PointF(xCenterOfImg, yPosFromBottom), strFormat);

            Bitmap bitmapWatermark = new Bitmap(bitmap);

            Graphics gWatermark = Graphics.FromImage(bitmapWatermark);

            ImageAttributes imageAttributes = new ImageAttributes();
            ColorMap colorMap = new ColorMap();

            colorMap.OldColor = Color.FromArgb(255, 0, 255, 0);
            colorMap.NewColor = Color.FromArgb(0, 0, 0, 0);
            ColorMap[] remapTable = { colorMap };

            imageAttributes.SetRemapTable(remapTable, ColorAdjustType.Bitmap);

            float[][] colorMatrixElements = { 
               new float[] {1.0f,  0.0f,  0.0f,  0.0f, 0.0f},
               new float[] {0.0f,  1.0f,  0.0f,  0.0f, 0.0f},
               new float[] {0.0f,  0.0f,  1.0f,  0.0f, 0.0f},
               new float[] {0.0f,  0.0f,  0.0f,  0.5f, 0.0f},
               new float[] {0.0f,  0.0f,  0.0f,  0.0f, 1.0f}
            };

            ColorMatrix wmColorMatrix = new ColorMatrix(colorMatrixElements);

            imageAttributes.SetColorMatrix(wmColorMatrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);


            int xPosOfWatermark = ((width - widthWatermark) - 10);
            int yPosOfWatermark = 10;

            gWatermark.DrawImage(imgWatermark, new Rectangle(xPosOfWatermark, yPosOfWatermark, widthWatermark, heightWatermark), 0, 0, widthWatermark, heightWatermark, GraphicsUnit.Pixel, imageAttributes);

            photo = bitmapWatermark;
            g.Dispose();
            gWatermark.Dispose();

            photo.Save(workingDirectory + "\\watermark_final.jpg", ImageFormat.Jpeg);
            
            photo.Dispose();
            bitmapWatermark.Dispose();
            imgWatermark.Dispose();
        }
    }
}
