


	1. Copy �Bodly� folder into the /themes folder on your site.
	2. Add script reference to the admin/settings/custom code/tracking script:

	<script type="text/javascript" defer="defer" src="/blog/js.axd?path=/blog/themes/Boldy/js/ddsmoothmenu.js"></script>

	*** remove "/blog" if your site is in the root or replace with your site name if it is not "blog" but something else
