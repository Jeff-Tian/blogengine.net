--
-- Create column "Views" on table "dbo.be_Posts"
--
ALTER TABLE dbo.be_Posts
  ADD [Views] int NULL default 0
GO