ALTER TABLE [be_Posts] ADD [Views] int NULL DEFAULT 0
GO

